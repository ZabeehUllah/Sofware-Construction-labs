Name: Haseeb Shah
Registration No: 00000131390
Section: 6A
Github Link: https://github.com/haseebs/software-construction-labs/tree/master/Lab8_Haseeb_Shah

Results:
Statement - autocommit: 14 seconds
PreparedStatement - autocommit: 16 seconds
Batch update - autocommit: 15 seconds
Statement - no autocommit: 1 seconds
PreparedStatement - no autocommit: 2 seconds
Batch update - no autocommit: 1 seconds
