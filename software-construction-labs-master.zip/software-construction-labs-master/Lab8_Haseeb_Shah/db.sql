CREATE DATABASE lab8;
CREATE TABLE student (
  `Name` varchar(100) DEFAULT NULL,
  `RegNo` int(11) DEFAULT NULL,
  `Semester` varchar(5) DEFAULT NULL,
  `Address` varchar(20) DEFAULT NULL
);